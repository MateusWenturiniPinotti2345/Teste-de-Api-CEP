// Função para mostrar o modal
function showCepModal(data) {
    // Obtém o elemento do modal de resultado do CEP pelo ID
    const modalResultadoCEP = document.getElementById('modalResultadoCEP');

    // Verifica se o elemento do modal de resultado do CEP existe
    if (modalResultadoCEP) {
        // Monta o HTML com os dados do CEP
        const resultado = `
            <h4 class='text-center'>Dados do CEP</h4>
            <p>Logradouro: ${data.logradouro}</p>
            <p>Bairro: ${data.bairro}</p>
            <p>Estado: ${data.uf}</p>
            <p>Cidade: ${data.localidade}</p>
            <p>DDD: ${data.ddd}</p>
            <p>IBGE: ${data.ibge}</p>
        `;

        // Define o conteúdo do modal com os dados do CEP
        modalResultadoCEP.innerHTML = resultado;

        // Cria uma instância do modal Bootstrap e a exibe
        const cepModal = new bootstrap.Modal(document.getElementById('cepModal'));
        cepModal.show();
    }
}

// Função para mostrar modal de erro
function showErrorModal(message) {
    // Obtém o elemento do modal de resultado do CEP pelo ID
    const modalResultadoCEP = document.getElementById('modalResultadoCEP');

    // Verifica se o elemento do modal de resultado do CEP existe
    if (modalResultadoCEP) {
        // Monta o HTML com a mensagem de erro
        const resultado = `
            <h4 class='text-center'>Erro</h4>
            <p>${message}</p>
        `;

        // Define o conteúdo do modal de erro
        modalResultadoCEP.innerHTML = resultado;

        // Cria uma instância do modal Bootstrap e a exibe
        const cepModal = new bootstrap.Modal(document.getElementById('cepModal'));
        cepModal.show();
    }
}

// Adiciona ouvinte de evento ao botão "Buscar CEP" e à tecla Enter
document.getElementById('buscarCEP').addEventListener('click', consultarCep);
document.getElementById('cep').addEventListener('keyup', (event) => {
    // Verifica se a tecla pressionada é Enter
    if (event.key === "Enter") {
        consultarCep();
    }
});

// Função para consultar o CEP
function consultarCep() {
    // Obtém o elemento de entrada do CEP pelo ID
    const cepInput = document.getElementById('cep');

    // Obtém o valor do CEP e remove caracteres não numéricos
    const cep = cepInput.value.replace(/\D/g, '');

    // Verifica se o CEP possui exatamente 8 dígitos
    if (!/^\d{8}$/.test(cep)) {
        // Exibe um modal de erro com a mensagem
        showErrorModal('CEP inválido! Digite exatamente 8 números.');
        return;
    }

    // Define a URL da API de consulta de CEP
    const url = `https://viacep.com.br/ws/${cep}/json/`;

    // Exibe um indicador de carregamento visual
    showLoadingIndicator();

    // Faz uma requisição à API de CEP
    fetch(url)
        .then(response => response.json())
        .then(data => {
            // Remove o indicador de carregamento visual
            hideLoadingIndicator();

            // Verifica se não há erro nos dados retornados
            if (!('erro' in data)) {
                // Exibe um modal com os dados do CEP
                showCepModal(data);
            } else {
                // Exibe um modal de erro com a mensagem
                showErrorModal('CEP não encontrado. Por favor, verifique o CEP e tente novamente.');
            }
        })
        .catch(error => {
            // Registra um erro no console
            console.error('Ocorreu um erro', error);

            // Remove o indicador de carregamento visual
            hideLoadingIndicator();

            // Exibe um modal de erro com a mensagem
            showErrorModal('Erro ao buscar o CEP. Por favor, tente novamente mais tarde.');
        });
}

// Função para limpar o campo de CEP
function limparCep() {
    // Obtém o elemento de entrada do CEP pelo ID
    const cepInput = document.getElementById('cep');

    // Limpa o valor do campo de CEP
    cepInput.value = '';
}

// Função para exibir o indicador de carregamento visual
function showLoadingIndicator() {
    // Obtém o elemento do indicador de carregamento pelo ID
    const loadingIndicator = document.getElementById('loadingIndicator');

    // Verifica se o elemento do indicador de carregamento existe
    if (loadingIndicator) {
        // Exibe o indicador de carregamento
        loadingIndicator.style.display = 'block';
    }
}

// Função para ocultar o indicador de carregamento visual
function hideLoadingIndicator() {
    // Obtém o elemento do indicador de carregamento pelo ID
    const loadingIndicator = document.getElementById('loadingIndicator');

    // Verifica se o elemento do indicador de carregamento existe
    if (loadingIndicator) {
        // Oculta o indicador de carregamento
        loadingIndicator.style.display = 'none';
    }
}

// Adiciona ouvinte de evento ao botão "Limpar CEP"
document.getElementById('limparCEP').addEventListener('click', limparCep);
